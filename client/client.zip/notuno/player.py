class Player:
  def __init__(self, username):
    self.username = username