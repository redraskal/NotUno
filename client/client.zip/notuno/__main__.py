from notuno.client import NotUnoClient

def main():
  NotUnoClient()

if __name__ == "__main__":
  main()