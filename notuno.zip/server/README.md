# (Not)Uno Server

You can optionally modify server/config/production.json and then use the Dockerfile or docker-compose.yml to launch your own server.

Alternatively, choose npm or yarn and run either
```bash
npm install
npm run dev
```
or
```bash
yarn install
yarn dev
```