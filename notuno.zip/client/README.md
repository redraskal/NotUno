# (Not)Uno Client

Install the required dependencies with ```pip install -r requirements.txt``` and run ```python notuno.py``` in the client directory to start the game client on the cli.